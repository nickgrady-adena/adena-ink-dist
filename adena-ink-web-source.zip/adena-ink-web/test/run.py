import asyncio, json, pathlib
from playwright.async_api import async_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = pathlib.Path('/tmp/claude-0/inkshots'); OUT.mkdir(exist_ok=True)

# A notebook exactly as the Chrome extension saves it
EXT_NB = {
  "app": "adena-ink", "v": 1, "name": "Fractions lesson", "subject": "Maths", "savedAt": 1763300000000,
  "boards": [
    {"name": "Board 1", "bg": "grid", "objs": [
      {"id": 1, "type": "stroke", "tool": "pen", "color": "#e5484d", "size": 4, "pts": [[200, 200], [260, 240], [330, 210], [400, 260]]},
      {"id": 2, "type": "stroke", "tool": "highlighter", "color": "#ffd60a", "size": 4, "pts": [[200, 300], [500, 300]]},
      {"id": 3, "type": "shape", "kind": "star", "color": "#0091ff", "size": 4, "x1": 600, "y1": 150, "x2": 720, "y2": 270},
      {"id": 4, "type": "tpl", "tpl": "fc4", "x": 820, "y": 140, "w": 200, "ink": "#0b1f4d"},
      {"id": 5, "type": "text", "x": 200, "y": 400, "text": "One quarter = 1/4", "color": "#1c1c1c", "fs": 28},
      {"id": 6, "type": "sticker", "emoji": "⭐", "x": 620, "y": 380, "size": 56},
      {"id": 7, "type": "note", "style": "yellow", "x": 800, "y": 420, "w": 200, "h": 160, "text": "Homework: page 42", "fs": 20, "rot": 0}
    ]},
    {"name": "Board 2", "bg": "chalk", "objs": [{"id": 8, "type": "tpl", "tpl": "venn2", "x": 300, "y": 150, "w": 440, "ink": "#ffffff"}]}
  ]
}

STUB = """
(() => {
  const NBS = [
    {id:'f1', name:'Fractions lesson', modified: Date.now()-3600e3, size: 2000, subject: 'Maths'},
    {id:'f2', name:'Whiteboard Nov 12', modified: Date.now()-4*864e5, size: 900, subject: ''}];
  const FILES = { f1: %s, f2: JSON.stringify({app:'adena-ink',v:1,name:'x',boards:[{name:'Board 1',bg:'white',objs:[]}]}) };
  window.__saved = [];
  const H = {
    boot: () => ({email:'teacher@example.org', first:'Nick'}),
    listNotebooks: () => NBS,
    getNotebook: (id) => ({id, name: NBS.find(n=>n.id===id).name, text: FILES[id]}),
    saveNotebook: (id, name, text) => { window.__saved.push({id, name, text}); return {id: id || 'new1', saved: Date.now()}; },
    renameNotebook: () => true, deleteNotebook: () => true,
  };
  const mk = (ok, fail) => new Proxy({}, { get(_, k) {
    if (k === 'withSuccessHandler') return (f) => mk(f, fail);
    if (k === 'withFailureHandler') return (f) => mk(ok, f);
    if (k === 'withUserObject') return () => mk(ok, fail);
    return (...a) => setTimeout(() => { try { ok && ok(H[k](...a)); } catch (e) { fail && fail(e); } }, 50);
  }});
  window.google = { script: { run: mk(null, null) } };
})();
""" % json.dumps(json.dumps(EXT_NB))

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={'width': 1440, 'height': 860})
        errs = []
        pg.on('pageerror', lambda e: errs.append('PAGEERR ' + str(e)))
        pg.on('console', lambda m: m.type == 'error' and errs.append('CONSOLE ' + m.text))
        await pg.add_init_script(STUB)
        await pg.goto((ROOT / 'dist' / 'App.html').as_uri())
        await pg.wait_for_timeout(600)
        await pg.screenshot(path=str(OUT / '1_landing.png'))

        # open the extension-made notebook
        await pg.click('[data-id="f1"]'); await pg.wait_for_timeout(700)
        await pg.screenshot(path=str(OUT / '2_ext_notebook.png'))
        st = await pg.evaluate("({pages: __ink.S.pages.length, objs: __ink.S.pages[0].objs.length, name: __ink.S.nb.name})")
        print('loaded', st)

        # draw a pen stroke, a shape and place a template
        await pg.mouse.move(300, 600); await pg.mouse.down(); await pg.mouse.move(380, 640, steps=8); await pg.mouse.move(460, 600, steps=8); await pg.mouse.up()
        await pg.click('#shapeBtn'); await pg.click('.shp [data-s="ellipse"]')
        await pg.mouse.move(1100, 600); await pg.mouse.down(); await pg.mouse.move(1250, 700, steps=6); await pg.mouse.up()
        await pg.click('[data-menu="subjects"]'); await pg.wait_for_timeout(300)
        await pg.screenshot(path=str(OUT / '3_subjects.png'))
        await pg.click('[data-tpl="clock"]'); await pg.mouse.click(1150, 300); await pg.wait_for_timeout(200)
        await pg.click('[data-menu="classroom"]'); await pg.wait_for_timeout(300)
        await pg.screenshot(path=str(OUT / '4_classroom.png'))
        await pg.keyboard.press('Escape')
        for w in ['timer', 'dice', 'ruler', 'prot', 'spot']:
            await pg.evaluate("w => __ink.toggleWidget(w)", w)
        await pg.evaluate("__ink.toggleLens()")
        await pg.wait_for_timeout(500)
        await pg.screenshot(path=str(OUT / '5_widgets.png'))
        for w in ['timer', 'dice', 'ruler', 'prot', 'spot']:
            await pg.evaluate("w => __ink.toggleWidget(w)", w)
        await pg.evaluate("__ink.toggleLens()")
        for w in ['strip', 'cover']:
            await pg.evaluate("w => __ink.toggleWidget(w)", w)
        await pg.wait_for_timeout(200)
        await pg.screenshot(path=str(OUT / '6_strip_cover.png'))
        for w in ['strip', 'cover']:
            await pg.evaluate("w => __ink.toggleWidget(w)", w)
        await pg.evaluate("__ink.toggleWidget('exam')"); await pg.wait_for_timeout(200)
        await pg.screenshot(path=str(OUT / '7_exam.png'))
        await pg.evaluate("__ink.toggleWidget('exam')")

        # eraser (whole) on the star, partial on the red stroke
        n0 = await pg.evaluate("__ink.S.pages[0].objs.length")
        await pg.click('[data-tool="eraser"]'); await pg.mouse.move(660, 152); await pg.mouse.down(); await pg.mouse.move(662, 154); await pg.mouse.up()
        n1 = await pg.evaluate("__ink.S.pages[0].objs.length")
        await pg.keyboard.press('Control+z')
        n2 = await pg.evaluate("__ink.S.pages[0].objs.length")
        print('erase whole', n0, '->', n1, 'undo ->', n2)

        # select + move the note, then text tool
        await pg.click('[data-tool="select"]'); await pg.mouse.move(900, 500); await pg.mouse.down(); await pg.mouse.move(950, 520, steps=5); await pg.mouse.up()
        note = await pg.evaluate("__ink.S.pages[0].objs.find(o=>o.type==='note')")
        print('note moved to', note['x'], note['y'])
        await pg.click('[data-tool="text"]'); await pg.mouse.click(200, 520); await pg.keyboard.type('Typed on the web'); await pg.mouse.click(700, 700)
        has_text = await pg.evaluate("__ink.S.pages[0].objs.some(o=>o.type==='text' && o.text==='Typed on the web')")
        print('text added', has_text)

        # boards menu: rail + new board
        await pg.click('[data-menu="boards"]'); await pg.wait_for_timeout(200)
        await pg.click('[data-rail="1"]'); await pg.click('[data-new="lined"]'); await pg.wait_for_timeout(500)
        await pg.screenshot(path=str(OUT / '8_rail_newboard.png'))

        # save + go home
        await pg.click('#homeBtn'); await pg.wait_for_timeout(800)
        saved = await pg.evaluate("window.__saved.length ? JSON.parse(window.__saved.at(-1).text) : null")
        print('saved boards', len(saved['boards']), 'kinds', sorted({o['type'] for bd in saved['boards'] for o in bd['objs']}), 'shape kinds', sorted({o.get('kind') for bd in saved['boards'] for o in bd['objs'] if o['type']=='shape'}))
        await pg.screenshot(path=str(OUT / '9_back_home.png'))

        # new board from landing + phone size
        await pg.click('.bgo[data-bg="chalk"]'); await pg.wait_for_timeout(300)
        await pg.set_viewport_size({'width': 390, 'height': 800}); await pg.wait_for_timeout(300)
        await pg.screenshot(path=str(OUT / '10_phone_board.png'))
        await pg.click('#homeBtn'); await pg.wait_for_timeout(300)
        await pg.screenshot(path=str(OUT / '11_phone_landing.png'), full_page=True)
        print('errors:', errs or 'none')
        await b.close()

if __name__ == "__main__":
    asyncio.run(main())
